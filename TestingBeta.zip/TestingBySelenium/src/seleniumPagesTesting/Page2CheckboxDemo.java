package seleniumPagesTesting;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;


public class Page2CheckboxDemo {

	WebDriver driver;
	
	By checkBox1 = By.id("isAgeSelected");
	
	public Page2CheckboxDemo(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickCheckbox()
	{
		driver.findElement(checkBox1).click();
	}
	
}
