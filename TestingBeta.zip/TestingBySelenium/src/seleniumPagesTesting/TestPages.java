package seleniumPagesTesting;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import junit.framework.Assert;

public class TestPages {

	@Before
	public void setUp()
	{
		System.setProperty("webdriver.gecko.driver","C:/Seleniumpliki/geckodriver.exe");
	}
	
	@Test
	public void testPage1() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("https://beta.bigstar.pl/c-kobieta?filters=p-1_r-48_o-nhl");
		//driver.get("https://beta.bigstar.pl/c-kobieta?filters=p-1_r-48_o-nhl");
		//driver.get("https://translate.google.pl/?hl=pl");
		
		Page1SimpleFormDemo object = new Page1SimpleFormDemo(driver);
		
		object.clickMessage();
		object.inputMessage();
		object.clickButton();

		Assert.assertTrue(driver.getPageSource().contains("Siemaneczko"));
				
		driver.quit();
	}
	
	@Test
	public void testPage2() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("https://beta.bigstar.pl/c-kobieta?filters=p-1_r-48_o-nhl");
		
		Page2CheckboxDemo object = new Page2CheckboxDemo(driver);
		
		object.clickCheckbox();
	
		Assert.assertTrue(driver.getPageSource().contains("Success - Check box is checked"));
				
		driver.quit();
	}
	
	@Test
	public void testPage3() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("https://beta.bigstar.pl/c-kobieta?filters=p-1_r-48_o-nhl");
		
		Page3RadioButtonsDemo object = new Page3RadioButtonsDemo(driver);
		
		object.checkRadioButtons();
		object.clickButton();
		Assert.assertTrue(driver.getPageSource().contains("Sex : Female"));
		Assert.assertTrue(driver.getPageSource().contains("Age group: 15 - 50"));
				
		driver.quit();
	}
	@Test
	public void testPage4() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html");
		
		Page4BootstrapDatePicker object = new Page4BootstrapDatePicker(driver);
		
		object.clickPicker();
		object.inputDate();
		Assert.assertTrue("11/01/1996", true);
				
		driver.quit();
	}
	
	@Test
	public void testPage5() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/table-records-filter-demo.html");
		
		Page5TableFilterDemo object = new Page5TableFilterDemo(driver);
		
		object.clickFilter();
		object.countItem();
		Assert.assertEquals(2, 2);
				
		driver.quit();
	}
	@Test
	public void testPage6() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/jquery-download-progress-bar-demo.html");
		
		Page6JQueryUIProgressBar object = new Page6JQueryUIProgressBar(driver);
		
		object.clickStart();
		object.clickClose();
		object.afterClose();
		Assert.assertTrue(object.afterClose());
				
		driver.quit();
	}
	
	@Test
	public void testPage7() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/bootstrap-alert-messages-demo.html");
		
		Page7BootstrpAlertMessages object = new Page7BootstrpAlertMessages(driver);
		
		object.clickButtons();
		Assert.assertEquals(object.isButtonsEnabled(), true);
		object.closeByButtons();
		Assert.assertTrue(driver.getPageSource().contains(""));
				
		driver.quit();
	}
	
	@Test
	public void testPage8() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/bootstrap-dual-list-box-demo.html");
		
		
		
		Page8DualListBoxExample object = new Page8DualListBoxExample(driver);
		
		object.searchTextBox();
		Assert.assertTrue(driver.getPageSource().contains("Dapibus ac facilisis in"));
		object.clickButtons1();	
		Assert.assertTrue(driver.getPageSource().contains(""));
		driver.quit();
	}
	
	@Test
	public void testPage9() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/dynamic-data-loading-demo.html");
		
		
		
		Page9LoadingTheDataDynamically object = new Page9LoadingTheDataDynamically(driver);
		
		object.clickTest();
		Assert.assertTrue(object.loadData());
		Assert.assertTrue(object.findData());
		driver.quit();
	}
	
	@Test
	public void testPage10() throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/data-list-filter-demo.html");
		
		
		
		Page10DataListFilter object = new Page10DataListFilter(driver);
		
		object.searchFilter();
		object.filter();
		Assert.assertTrue(driver.getPageSource().contains("Glenn"));
		driver.quit();
	}
	
	
	
	@After
	public void afterTests()
	{
		System.gc();
		
	}
}