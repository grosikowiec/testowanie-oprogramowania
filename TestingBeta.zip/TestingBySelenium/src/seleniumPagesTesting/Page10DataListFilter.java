package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page10DataListFilter {

	WebDriver driver;
	By inputSearch =By.xpath("//*[@id='input-search']");
	
	public Page10DataListFilter(WebDriver driver)
	{
		this.driver = driver;
	}
	public void searchFilter()
	{
		driver.findElement(inputSearch).click();		
	}
	public void filter()
	{
		driver.findElement(inputSearch).sendKeys("glenn");
	}
}