package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page7BootstrpAlertMessages {

	WebDriver driver;
	By autocloseableSucces =By.xpath("//*[@id='autoclosable-btn-success']");
	By normalSucces = By.xpath("//*[@id='normal-btn-success']");
	By autocloseableWarning = By.xpath("//*[@id='autoclosable-btn-warning']");
	By normalWarning = By.xpath("//*[@id='normal-btn-warning']");
	By autocloseableDanger = By.xpath("//*[@id='autoclosable-btn-danger']");
	By normalDanger = By.xpath("//*[@id='normal-btn-danger']");
	By autocloseableInfo = By.xpath("//*[@id='autoclosable-btn-info']");
	By normalInfo = By.xpath("//*[@id='normal-btn-info']");
	
	public Page7BootstrpAlertMessages(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickButtons()
	{
		driver.findElement(autocloseableSucces).click();
		driver.findElement(normalSucces).click();
		driver.findElement(autocloseableWarning).click();
		driver.findElement(normalWarning).click();
		driver.findElement(autocloseableDanger).click();
		driver.findElement(normalDanger).click();
		driver.findElement(autocloseableInfo).click();
		driver.findElement(normalInfo).click();
		
	}
	public boolean isButtonsEnabled()
	{
		while(true)
		{
			if(driver.findElement(autocloseableSucces).isEnabled()==true && driver.findElement(autocloseableWarning).isEnabled()==true && driver.findElement(autocloseableDanger).isEnabled()==true && driver.findElement(autocloseableInfo).isEnabled()==true)
			{
				return true;
			}
			else
				continue;
		}
	}
	public void closeByButtons()
	{
		driver.findElement(normalSucces).click();
		driver.findElement(normalWarning).click();
		driver.findElement(normalDanger).click();
		driver.findElement(normalInfo).click();
	}
	
	
}