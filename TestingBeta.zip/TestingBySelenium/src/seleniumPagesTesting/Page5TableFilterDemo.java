package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page5TableFilterDemo {

	WebDriver driver;
	By filterOrange =By.xpath("/html/body/div[2]/div/div[2]/section/div/div/div[2]/div[1]/div/button[2]");
	By o1 =By.xpath("/html/body/div[2]/div/div[2]/section/div/div/div[2]/div[2]/table/tbody/tr[2]/td[3]/div/div/h4/span");
	By o2 =By.xpath("/html/body/div[2]/div/div[2]/section/div/div/div[2]/div[2]/table/tbody/tr[5]/td[3]/div/div/h4/span");
	public Page5TableFilterDemo(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickFilter()
	{
		driver.findElement(filterOrange).click();
	}
	public int countItem()
	{
		if(driver.findElement(o1).getText()=="(Orange)" && driver.findElement(o2).getText()=="(Orange)")
			return 2;
		else
			return 0;
	}
}
