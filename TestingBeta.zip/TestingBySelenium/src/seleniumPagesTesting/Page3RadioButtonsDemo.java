package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page3RadioButtonsDemo {

WebDriver driver;
	
	By radioButtonGender = By.xpath("//input[@name='gender'][@value='Female']");
	By radioButtonAge = By.xpath("//input[@value='15 - 50']");
	By button=By.xpath("/html/body/div[2]/div/div[2]/div[2]/div[2]/button");
	
	
	public Page3RadioButtonsDemo(WebDriver driver)
	{
		this.driver = driver;
	}
	public void checkRadioButtons()
	{
		driver.findElement(radioButtonGender).click();
		driver.findElement(radioButtonAge).click();
	}
	public void clickButton()
	{
		driver.findElement(button).click();
	}
}
