package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page9LoadingTheDataDynamically {

	WebDriver driver;
	By getUser =By.xpath("//*[@id='save']");
	By loadingImage = By.xpath("//img[@src='http://seleniumeasy.com/test/img/loader-image.gif']");
	By picture = By.xpath("//img[@src='https://randomuser.me/api/portraits/.']");
	By picturee = By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/div/img");
	By load = By.id("loading");
	public Page9LoadingTheDataDynamically(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickTest()
	{
		driver.findElement(getUser).click();
		
	}
	public boolean loadData()
	{		
		while(true)
		{
			if(driver.findElement(loadingImage).isDisplayed()==false)
				return true;
			else 
				continue;
		}
	}
	public boolean findData()
	{
		while(true)
		{
			//System.out.println(driver.findElement(load).getText());
			if(driver.findElement(load).getText().equals("loading..."))
				continue;
			else
				return true;
		}
		
	}
	
}