package seleniumPagesTesting;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;


public class Page1SimpleFormDemo {

	WebDriver driver;
	
	By textBoxSingle1 = By.id("user-message");
	By buttonShowMessage1 = By.xpath("//button[@onclick='showInput();']");
	
	public Page1SimpleFormDemo(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickMessage()
	{
		driver.findElement(textBoxSingle1).click();
	}
	
	public void inputMessage()
	{
		driver.findElement(textBoxSingle1).sendKeys("Siemaneczko");
	}
	
	public void clickButton()
	{
		driver.findElement(buttonShowMessage1).click();
	}
	
}
