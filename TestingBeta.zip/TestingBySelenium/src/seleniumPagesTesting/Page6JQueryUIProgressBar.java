package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page6JQueryUIProgressBar {

WebDriver driver;
	
	By startButton = By.xpath("//button[@id='downloadButton']");
	By cancelButton = By.xpath("//html/body/div[3]/div[3]/div/button");
	By closeButton = By.xpath("/html/body/div[3]/div[3]/div/button");
	By progressLabel = By.xpath("/html/body/div[3]/div[2]/div[1]");
	By startButtonAfterClose = By.xpath("//*[@id='downloadButton']");
	public boolean isDownloaded = false;
	public Page6JQueryUIProgressBar(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickStart()
	{
		driver.findElement(startButton).click();
	}
	public void clickCancel()
	{
		driver.findElement(cancelButton).click();
	}
	public void clickClose()
	{
		while(true)
		{
			//System.out.println(driver.findElement(progressLabel).getText().toString());
			if(driver.findElement(progressLabel).getText().toString().equals("Complete!"))
			{
				driver.findElement(closeButton).click();
				isDownloaded=true;
				break;
			}
		}
		
	}
	public boolean afterClose()
	{
		if(isDownloaded)
		{
			return true;
		}
		else
			return false;
	}
	
}
