package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page4BootstrapDatePicker {

	WebDriver driver;
	By datePicker =By.xpath("//*[@id='sandbox-container1']/div");
	By inputDate = By.xpath("/html/body/div[2]/div/div[2]/div[1]/div/div[2]/div/div/input");
	
	public Page4BootstrapDatePicker(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickPicker()
	{
		driver.findElement(datePicker).click();
	}
	
	public void inputDate()
	{
		driver.findElement(inputDate).sendKeys("11/01/1996");
	}
	
}
