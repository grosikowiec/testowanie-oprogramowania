package seleniumPagesTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page8DualListBoxExample {

	WebDriver driver;
	By selectAll1 =By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/div/div[2]/div/a/i");
	By selectAll2 =By.xpath("/html/body/div[2]/div/div[2]/div/div[3]/div/div/div[1]/div/a/i");	
	By moveTo2 = By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/button[2]");
	By moveTo1 = By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/button[1]");
	By list = By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul");
	By searchBox1 = By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/div/div[1]/div/input");
	By searchBox2 = By.xpath("");
	By block = By.xpath("//li[@class='list-group-item']");
	By ggg = By.xpath("<//ul{@class='list-group']");
	
	public Page8DualListBoxExample(WebDriver driver)
	{
		this.driver = driver;
	}
	public void clickButtons1()
	{
		driver.findElement(selectAll1).click();
		driver.findElement(moveTo2).click();	
		driver.findElement(selectAll2).click();
		driver.findElement(moveTo1).click();
		
	}
	public void searchTextBox()
	{
		driver.findElement(searchBox1).sendKeys("Dapibus ac facilisis in");
		driver.findElement(block);
		driver.findElement(moveTo2).click();
	}
	public boolean isEmpty()
	{
		if(driver.findElement(ggg).findElement(block)==null)
		{
			return true;
		}
		else
			return false;
	}
	
}